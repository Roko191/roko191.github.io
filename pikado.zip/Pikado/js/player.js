function Player(ime, points)
{
    this.ime = ime,
    this.points = points,
    this.winner = false
};